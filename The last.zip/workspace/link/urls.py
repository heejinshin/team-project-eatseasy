from django.urls import path
from .views import *

app_name = 'link'

urlpatterns = [
path('search', UserCreateSearchView.as_view(), name='search'), 
path('location', UserCreateLocationView.as_view(), name='location'),
]
