from django.shortcuts import render
from django.views import generic


class UserCreateSearchView(generic.TemplateView):
    template_name = 'link/search.html'

class UserCreateLocationView(generic.TemplateView):
    template_name = 'link/location.html'


