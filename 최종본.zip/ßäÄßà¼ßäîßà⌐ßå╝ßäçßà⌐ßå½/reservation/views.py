from django.forms import widgets
from django.shortcuts import render
from django.views.generic import ListView, DetailView
from reservation.models import Post, Customer

from django.views.generic import CreateView, UpdateView, DeleteView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.urls import reverse_lazy
from accounts.views import OwnerOnlyMixin

from django import forms # HiddenInput
from django.contrib import messages #예약좌석 초과시 에러메시지


###############################################################
# 가게 목록, 가게 상세 정보
###############################################################
class PostListView(ListView):
    model = Post
    template_name = 'reservation/post_all.html'   # 템플릿 파일명 변경
    context_object_name = 'posts'                 # 컨텍스트 객체 이름 변경(object_list)
    paginate_by = 8                               # 페이지네이션, 페이지당 문서 건 수




class PostDetailView(DetailView):
    model = Post



        

###########################################################################################
# 가게 등록, 수정, 삭제
#########################################################
class PostCreateView(LoginRequiredMixin, CreateView):
    model = Post
    fields = [
        'restaurant_name', 
        'restaurant_description', 
        'restaurant_callnumber',
        'restaurant_address',
        'reservation_possible_date',
        'reservation_time_begin',
        'reservation_time_end',
        'reservation_seat'                           
        ]
    success_url = reverse_lazy('reservation:index')

    def form_valid(self, form):
        form.instance.owner = self.request.user
        return super().form_valid(form)



class PostUpdateView(OwnerOnlyMixin, UpdateView):
    model = Post
    fields = [
        'restaurant_name', 
        'restaurant_description', 
        'restaurant_callnumber',
        'restaurant_address',
        'reservation_possible_date',
        'reservation_time_begin',
        'reservation_time_end',
        'reservation_seat'      
                       
        ]
    success_url = reverse_lazy('reservation:index')

    

class PostDeleteView(OwnerOnlyMixin, DeleteView):
    model = Post
    success_url = reverse_lazy('reservation:index')

    def get(self, *args, **kwargs):
        return self.post(*args, **kwargs)



##################################################
#예약 확인, 상세 정보
##################################################

class CustomerListView(ListView):
    model = Customer                 
    template_name = 'reservation/customer_reservation.html'                         
    paginate_by = 10

class CustomerDetailView(DetailView):
    model = Customer


##################################################
#예약 하기, 수정하기, 삭제하기
##################################################
class CustomerCreateView(LoginRequiredMixin, CreateView):
           
    model = Customer  
        
    fields = [
        # 'owner_id',
        
        'customer_reservation_restaurant_id',
        'customer_reservation_restaurant',
        'customer_name',
        'customer_callnumber',
        'customer_reservation_date',
        'customer_reservation_time',
        'customer_seatscount'                        
        ]
          
    success_url = reverse_lazy('reservation:customerindex')

    def post(self, request, *args, **kwargs):   #장고 내장 유효성검사 
        self.object = None
        form = self.get_form()
        if form.is_valid():
            restaurant = Post.objects.get(restaurant_name = form.instance.customer_reservation_restaurant)
            
            total = restaurant.reservation_customer_seat + form.instance.customer_seatscount
            over_num = total - restaurant.reservation_seat
            if restaurant.reservation_seat >= total:  # 성공
                return self.form_valid(form)
            else: # 예약 다 찼을때 띄울 메시지 넣기 
                messages.add_message(request, messages.INFO, f'예약이 꽉 찼습니다. {over_num}명 초과입니다.')
                return super().form_invalid(form)

        else:
            return super().form_invalid(form)


### 강사님이 해주신 것/ 음식점 이름 자동 완성
    def get_form(self):
        form = super().get_form()
        if self.request.method == 'GET':
            r_id = self.request.GET['restaurant']
            restaurant = Post.objects.get(pk=r_id)

            r_field = form.fields['customer_reservation_restaurant']
            r_field.initial = restaurant.restaurant_name
            
            r_field2 = form.fields['customer_reservation_restaurant_id']
            r_field2.initial = restaurant.id
            r_field2.widget = forms.HiddenInput()


        return form

  
    def form_valid(self, form):
        form.instance.owner = self.request.user
        result = super().form_valid(form)  # Customer 저장 
        
        #Post의 customer_seatscount 업데이트 
        restaurant = Post.objects.get(restaurant_name = form.instance.customer_reservation_restaurant)
        restaurant.reservation_customer_seat += form.instance.customer_seatscount
        restaurant.save()

        return result

    


class CustomerUpdateView(OwnerOnlyMixin, UpdateView):
    model = Customer
    fields = [
        'customer_reservation_restaurant',
        'customer_name',
        'customer_callnumber',
        
        
        'customer_reservation_date',
        'customer_reservation_time',
        'customer_seatscount',
        'customer_update_seats'                     
        ]
    success_url = reverse_lazy('reservation:customerindex')

    def post(self, request, *args, **kwargs):  
        # self.object = None
        form = self.get_form()
        if form.is_valid():
            restaurant = Post.objects.get(restaurant_name = form.instance.customer_reservation_restaurant)
            
            total = restaurant.reservation_customer_seat + form.instance.customer_update_seats 
            over_num = total - restaurant.reservation_seat
            if restaurant.reservation_seat >= total:  # 성공
                result = self.form_valid(form)
                c = self.get_object()
                c.customer_seatscount +=  form.instance.customer_update_seats 
                c.save()
                return result

            else: # 예약 다 찼을때 띄울 메시지 넣기 
                messages.add_message(request, messages.INFO, f'예약이 꽉 찼습니다. {over_num}명 초과입니다.')
                return super().form_invalid(form)
        else:
            return super().form_invalid(form)


    def form_valid(self, form):
        form.instance.owner = self.request.user
        result = super().form_valid(form)  # Customer 저장 
        
        #Post의 customer_seatscount 업데이트 
        restaurant = Post.objects.get(restaurant_name = form.instance.customer_reservation_restaurant)
        restaurant.reservation_customer_seat += form.instance.customer_update_seats
        # restaurant.reservation_customer_seat += form.instance.customer_update_seats

        restaurant.save()

        return result


class CustomerDeleteView(OwnerOnlyMixin, DeleteView):
    model = Customer
    success_url = reverse_lazy('reservation:customerindex')


    def post(self, request, *args, **kwargs):
        self.object = self.get_object()
        restaurant = Post.objects.get(restaurant_name = self.object.customer_reservation_restaurant)
        restaurant.reservation_customer_seat -= self.object.customer_seatscount 
        restaurant.save()        
        return super().post(request, *args, **kwargs)


    def get(self, *args, **kwargs):
        return self.post(*args, **kwargs)

